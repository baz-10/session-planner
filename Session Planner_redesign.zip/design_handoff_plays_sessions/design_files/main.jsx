// Main - wire everything onto the design canvas

function App() {
  return (
    <DesignCanvas title="Session Planner · Plays + Sessions Redesign">
      <DCSection id="plays" title="Plays · Play editor" subtitle="Live court theme toggle in the top bar — Hardwood / Tactical / Blueprint. Choice persists per user via localStorage. Click the artboard to focus.">
        <DCArtboard id="play-editor" label="Play editor · switchable court theme" width={1280} height={820} scale={0.7}>
          <PlayEditorShell theme="hardwood" title="Horns flare · BLOB" subtitle="Offense · ATO" />
        </DCArtboard>
      </DCSection>

      <DCSection id="courts-only" title="Courts · isolated" subtitle="The court surfaces alone, without editor chrome.">
        <DCArtboard id="c-hw" label="Hardwood" width={800} height={800} scale={0.5}>
          <div style={{ width: 800, height: 800, position: 'relative' }}><CourtHardwood style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} /></div>
        </DCArtboard>
        <DCArtboard id="c-tc" label="Tactical" width={800} height={800} scale={0.5}>
          <div style={{ width: 800, height: 800, position: 'relative' }}><CourtTactical style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} /></div>
        </DCArtboard>
        <DCArtboard id="c-bp" label="Blueprint" width={800} height={800} scale={0.5}>
          <div style={{ width: 800, height: 800, position: 'relative' }}><CourtBlueprint style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} /></div>
        </DCArtboard>
      </DCSection>

      <DCSection id="sessions" title="Session Planning · 3 directions" subtitle="Same session data, three layouts. Each is a full-width screen of the session-builder page.">
        <DCArtboard id="s-timeline" label="A · Timeline & ribbon" width={1280} height={1180} scale={0.55}>
          <SessionTimeline />
        </DCArtboard>
        <DCArtboard id="s-storyboard" label="B · Run of show" width={1280} height={1200} scale={0.55}>
          <SessionStoryboard />
        </DCArtboard>
        <DCArtboard id="s-pro" label="C · Dense pro (dark)" width={1280} height={900} scale={0.55}>
          <SessionPro />
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
