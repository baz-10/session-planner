// Session Timeline - visual time-block view, storyboard feel
// Activities appear as horizontal blocks on a clock/timeline

const SESSION = {
  name: 'Tuesday Practice · Ball-screen emphasis',
  date: 'Tue · Feb 4',
  start: '17:00',
  duration: 120,
  location: 'Lincoln HS · Main Gym',
  focus: { off: 'Horns, ball-screen reads', def: 'Drop coverage against PnR' },
  activities: [
    { id: 'a1', name: 'Dynamic warm-up', cat: 'Warmup', color: '#94a3b8', dur: 10, notes: 'Jog · skips · ladder · carioca' },
    { id: 'a2', name: '3-man weave', cat: 'Passing', color: '#f59e0b', dur: 12, notes: 'Full court, finish off glass' },
    { id: 'a3', name: 'Shell drill', cat: 'Defense', color: '#ef4444', dur: 15, notes: '4v4 close-outs · help rotations' },
    { id: 'a4', name: 'Horns install', cat: 'Play', color: '#14b8a6', dur: 20, notes: 'Walk thru → 5v0 → 5v5', play: 'Horns flare' },
    { id: 'a5', name: 'Ball-screen reads', cat: 'Play', color: '#14b8a6', dur: 15, notes: 'Reject · reject keep · pocket' },
    { id: 'a6', name: 'Transition 3v2 / 2v1', cat: 'Conditioning', color: '#8b5cf6', dur: 12, notes: 'Read numbers · paint touches' },
    { id: 'a7', name: 'Free throws', cat: 'Shooting', color: '#eab308', dur: 6, notes: 'Pressure · 2 makes in a row' },
    { id: 'a8', name: '5v5 scrimmage', cat: 'Live', color: '#1e3a5f', dur: 25, notes: 'Stop/score · live clock' },
    { id: 'a9', name: 'Cool down · film', cat: 'Wrap', color: '#64748b', dur: 5, notes: 'Stretch · 3 clips' },
  ],
};

function addMinutes(hhmm, mins) {
  const [h, m] = hhmm.split(':').map(Number);
  const total = h * 60 + m + mins;
  const H = Math.floor(total / 60) % 24;
  const M = total % 60;
  return `${String(H).padStart(2, '0')}:${String(M).padStart(2, '0')}`;
}

function fmt12(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  const ampm = h >= 12 ? 'pm' : 'am';
  const H = h % 12 === 0 ? 12 : h % 12;
  return `${H}:${String(m).padStart(2, '0')}${ampm}`;
}

// --- Variant 1: Timeline / ribbon layout ---
function SessionTimeline() {
  let clock = SESSION.start;
  const rows = SESSION.activities.map(a => {
    const startT = clock;
    clock = addMinutes(clock, a.dur);
    return { ...a, start: startT, end: clock };
  });
  const used = rows.reduce((s, r) => s + r.dur, 0);

  return (
    <div style={{ width: 1280, background: '#f8fafc', fontFamily: 'DM Sans', color: '#0f1f33' }}>
      {/* Hero */}
      <div style={{ padding: '28px 36px 24px', background: 'linear-gradient(135deg, #1e3a5f 0%, #0f1f33 100%)', color: '#fff', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', right: -80, top: -80, width: 340, height: 340, borderRadius: '50%', background: '#14b8a6', opacity: 0.18, filter: 'blur(80px)' }} />
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', position: 'relative' }}>
          <div style={{ maxWidth: 720 }}>
            <div className="mono" style={{ fontSize: 12, letterSpacing: 2, color: '#5eead4', fontWeight: 600 }}>SESSION PLAN</div>
            <div style={{ fontSize: 30, fontWeight: 700, letterSpacing: -0.4, marginTop: 6 }}>{SESSION.name}</div>
            <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.7)', marginTop: 6 }}>
              {SESSION.date} · {fmt12(SESSION.start)}–{fmt12(addMinutes(SESSION.start, SESSION.duration))} · {SESSION.location}
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', border: '1px solid rgba(255,255,255,0.2)', padding: '8px 14px', borderRadius: 8, fontSize: 13, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>Duplicate</button>
            <button style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', border: '1px solid rgba(255,255,255,0.2)', padding: '8px 14px', borderRadius: 8, fontSize: 13, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>Print</button>
            <button style={{ background: '#14b8a6', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer' }}>Save plan</button>
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginTop: 22 }}>
          {[
            { l: 'Duration', v: `${used} / ${SESSION.duration}`, s: 'min planned', accent: true },
            { l: 'Activities', v: rows.length, s: '3 drills · 2 plays · 4 blocks' },
            { l: 'Offense focus', v: SESSION.focus.off, small: true },
            { l: 'Defense focus', v: SESSION.focus.def, small: true },
          ].map((s, i) => (
            <div key={i} style={{ background: s.accent ? '#14b8a6' : 'rgba(255,255,255,0.08)', border: s.accent ? 'none' : '1px solid rgba(255,255,255,0.12)', borderRadius: 12, padding: '14px 16px' }}>
              <div className="mono" style={{ fontSize: 10, letterSpacing: 1.5, color: s.accent ? 'rgba(255,255,255,0.8)' : 'rgba(255,255,255,0.55)', fontWeight: 600 }}>{s.l.toUpperCase()}</div>
              <div style={{ fontSize: s.small ? 14 : 28, fontWeight: 700, marginTop: 4, lineHeight: 1.2 }}>{s.v}</div>
              {s.s && !s.small && <div className="mono" style={{ fontSize: 11, color: 'rgba(255,255,255,0.6)', marginTop: 2 }}>{s.s}</div>}
            </div>
          ))}
        </div>
      </div>

      {/* Timeline ribbon */}
      <div style={{ padding: '24px 36px', background: '#fff', borderBottom: '1px solid #e2e8f0' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 }}>
          <div style={{ fontSize: 16, fontWeight: 700 }}>Practice timeline</div>
          <div className="mono" style={{ fontSize: 12, color: '#64748b' }}>{fmt12(SESSION.start)} → {fmt12(addMinutes(SESSION.start, SESSION.duration))}</div>
        </div>
        <div style={{ display: 'flex', height: 56, borderRadius: 10, overflow: 'hidden', gap: 2, background: '#f1f5f9' }}>
          {rows.map(r => (
            <div key={r.id} style={{ flex: r.dur, background: r.color, position: 'relative', cursor: 'pointer', display: 'flex', alignItems: 'flex-end', padding: '6px 8px' }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#fff', textShadow: '0 1px 2px rgba(0,0,0,0.3)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {r.dur}m
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: 'flex', marginTop: 6, gap: 2 }}>
          {rows.map(r => (
            <div key={r.id} className="mono" style={{ flex: r.dur, fontSize: 10, color: '#64748b', textAlign: 'left' }}>{fmt12(r.start)}</div>
          ))}
        </div>
      </div>

      {/* Activity cards */}
      <div style={{ padding: '24px 36px 36px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <div style={{ fontSize: 16, fontWeight: 700 }}>Activities</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{ padding: '8px 14px', fontSize: 13, fontWeight: 600, border: '1.5px solid #14b8a6', color: '#14b8a6', background: '#fff', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>+ From library</button>
            <button style={{ padding: '8px 14px', fontSize: 13, fontWeight: 600, border: '1.5px solid #e2e8f0', color: '#1e3a5f', background: '#fff', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>+ Custom</button>
            <button style={{ padding: '8px 14px', fontSize: 13, fontWeight: 600, border: 'none', color: '#fff', background: 'linear-gradient(135deg, #14b8a6, #0d9488)', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>✦ Autopilot</button>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {rows.map((r, idx) => (
            <div key={r.id} style={{
              display: 'grid', gridTemplateColumns: '72px 72px 1fr 240px 140px 40px',
              background: '#fff', border: '1px solid #e2e8f0', borderRadius: 14,
              alignItems: 'stretch', overflow: 'hidden', position: 'relative',
            }}>
              <div style={{ background: r.color, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
                <div className="mono" style={{ fontSize: 10, letterSpacing: 1, opacity: 0.85 }}>#{idx + 1}</div>
                <div className="mono" style={{ fontSize: 16, fontWeight: 700 }}>{r.dur}</div>
                <div className="mono" style={{ fontSize: 9, opacity: 0.8 }}>MIN</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', borderRight: '1px solid #e2e8f0', background: '#f8fafc' }}>
                <div className="mono" style={{ fontSize: 13, fontWeight: 700, color: '#1e3a5f' }}>{fmt12(r.start).replace(/[ap]m/, '')}</div>
                <div className="mono" style={{ fontSize: 10, color: '#64748b' }}>→ {fmt12(r.end).replace(/[ap]m/, '')}</div>
              </div>
              <div style={{ padding: '14px 18px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{ fontSize: 15, fontWeight: 700 }}>{r.name}</div>
                  <span style={{ fontSize: 10, padding: '2px 8px', borderRadius: 100, background: r.color + '22', color: r.color, fontWeight: 700, letterSpacing: 0.5, textTransform: 'uppercase' }}>{r.cat}</span>
                  {r.play && (
                    <span style={{ fontSize: 10, padding: '2px 8px', borderRadius: 100, background: '#1e3a5f', color: '#fff', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                      <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#5eead4' }} /> {r.play}
                    </span>
                  )}
                </div>
                <div style={{ fontSize: 13, color: '#64748b', marginTop: 4 }}>{r.notes}</div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', padding: '10px 14px', borderLeft: '1px solid #e2e8f0' }}>
                {r.play ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{ width: 72, height: 54, borderRadius: 8, overflow: 'hidden', border: '1px solid #e2e8f0', position: 'relative' }}>
                      <CourtHardwood style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
                      <svg viewBox="0 0 1000 1000" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                        {[[500,760],[840,220],[160,220],[400,460],[600,460]].map(([x,y],i)=>
                          <circle key={i} cx={x} cy={y} r="40" fill="#fff8ed" stroke="#0f1f33" strokeWidth="6" />
                        )}
                      </svg>
                    </div>
                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, color: '#1e3a5f' }}>Linked play</div>
                      <div style={{ fontSize: 11, color: '#64748b' }}>v3 · synced</div>
                    </div>
                  </div>
                ) : (
                  <button style={{ fontSize: 12, color: '#64748b', border: '1px dashed #cbd5e1', background: 'transparent', padding: '6px 10px', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>+ Link a play</button>
                )}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 14px' }}>
                <div style={{ display: 'flex', marginLeft: 'auto' }}>
                  {['JW', 'MR', 'AP'].slice(0, 3).map((i, k) => (
                    <div key={k} style={{ width: 24, height: 24, borderRadius: '50%', background: ['#1e3a5f', '#14b8a6', '#f59e0b'][k], color: '#fff', fontSize: 9, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid #fff', marginLeft: k ? -6 : 0 }}>{i}</div>
                  ))}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8', fontSize: 18 }}>⋮</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

window.SessionTimeline = SessionTimeline;
window.SESSION_DATA = SESSION;
window.fmt12 = fmt12;
window.addMinutes = addMinutes;
