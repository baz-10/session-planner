// Session Storyboard - vertical "run of show" with phase bands & prominent imagery
function SessionStoryboard() {
  const data = window.SESSION_DATA;
  const fmt12 = window.fmt12, addMinutes = window.addMinutes;

  // Group into phases
  const phases = [
    { title: 'Warm-up', tint: '#94a3b8', ids: ['a1'] },
    { title: 'Skill block', tint: '#f59e0b', ids: ['a2', 'a3'] },
    { title: 'Install · Plays', tint: '#14b8a6', ids: ['a4', 'a5'] },
    { title: 'Competition', tint: '#8b5cf6', ids: ['a6', 'a7', 'a8'] },
    { title: 'Cool down', tint: '#64748b', ids: ['a9'] },
  ];

  let clock = data.start;
  const byId = {};
  data.activities.forEach(a => {
    byId[a.id] = { ...a, start: clock, end: addMinutes(clock, a.dur) };
    clock = addMinutes(clock, a.dur);
  });

  return (
    <div style={{ width: 1280, fontFamily: 'DM Sans', color: '#0f1f33', background: '#fafafa' }}>
      {/* Header */}
      <div style={{ padding: '24px 36px', background: '#fff', borderBottom: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div className="mono" style={{ fontSize: 11, letterSpacing: 2, color: '#14b8a6', fontWeight: 700 }}>RUN OF SHOW</div>
          <div style={{ fontSize: 24, fontWeight: 700, letterSpacing: -0.3, marginTop: 4 }}>{data.name}</div>
          <div style={{ fontSize: 13, color: '#64748b', marginTop: 4 }}>{data.date} · {fmt12(data.start)} · {data.location}</div>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <div style={{ textAlign: 'right', marginRight: 8 }}>
            <div className="mono" style={{ fontSize: 24, fontWeight: 700, color: '#1e3a5f', lineHeight: 1 }}>{data.duration}<span style={{ fontSize: 14, color: '#64748b', marginLeft: 4 }}>min</span></div>
            <div style={{ fontSize: 11, color: '#64748b' }}>{data.activities.length} activities · {phases.length} phases</div>
          </div>
          <button style={{ padding: '9px 16px', fontSize: 13, fontWeight: 700, border: 'none', color: '#fff', background: '#1e3a5f', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>Save plan</button>
        </div>
      </div>

      {/* Main storyboard - 2 col */}
      <div style={{ display: 'grid', gridTemplateColumns: '180px 1fr 280px', gap: 0 }}>
        {/* Left gutter: clock */}
        <div style={{ padding: '28px 20px 28px 36px', borderRight: '1px solid #e2e8f0', background: '#fff' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: 1.5, color: '#64748b', fontWeight: 700, marginBottom: 12 }}>CLOCK</div>
          <div style={{ position: 'relative' }}>
            {phases.map((p, pi) => {
              const totalMins = p.ids.reduce((s, id) => s + byId[id].dur, 0);
              const firstStart = byId[p.ids[0]].start;
              return (
                <div key={pi} style={{ display: 'flex', gap: 10, marginBottom: 24 }}>
                  <div style={{ width: 3, borderRadius: 2, background: p.tint, minHeight: 80 * (totalMins / 15) }} />
                  <div>
                    <div className="mono" style={{ fontSize: 13, fontWeight: 700, color: '#1e3a5f' }}>{fmt12(firstStart)}</div>
                    <div className="mono" style={{ fontSize: 10, color: '#64748b', marginTop: 2 }}>{totalMins} min</div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: p.tint, marginTop: 8, textTransform: 'uppercase', letterSpacing: 0.5 }}>{p.title}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Center: activity storyboard cards */}
        <div style={{ padding: '28px 24px', display: 'flex', flexDirection: 'column', gap: 24 }}>
          {phases.map((p, pi) => (
            <div key={pi}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: p.tint }} />
                <div style={{ fontSize: 14, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, color: '#1e3a5f' }}>{p.title}</div>
                <div style={{ flex: 1, height: 1, background: '#e2e8f0' }} />
                <div className="mono" style={{ fontSize: 11, color: '#64748b' }}>{p.ids.reduce((s, id) => s + byId[id].dur, 0)}m</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {p.ids.map(id => {
                  const r = byId[id];
                  return (
                    <div key={id} style={{ display: 'grid', gridTemplateColumns: r.play ? '96px 1fr 80px' : '1fr 80px', gap: 16, alignItems: 'center', background: '#fff', border: '1px solid #e2e8f0', borderRadius: 12, padding: 14 }}>
                      {r.play && (
                        <div style={{ width: 96, height: 72, borderRadius: 8, overflow: 'hidden', border: '1px solid #e2e8f0', position: 'relative' }}>
                          <CourtTactical style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
                          <svg viewBox="0 0 1000 1000" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                            <line x1="500" y1="760" x2="400" y2="460" stroke="#5eead4" strokeWidth="18" strokeDasharray="30 25" />
                            {[[500,760],[840,220],[160,220],[400,460],[600,460]].map(([x,y],i)=>
                              <circle key={i} cx={x} cy={y} r="42" fill="#5eead4" stroke="#0b1424" strokeWidth="6" />
                            )}
                          </svg>
                        </div>
                      )}
                      <div>
                        <div style={{ fontSize: 15, fontWeight: 700 }}>{r.name}</div>
                        <div style={{ fontSize: 12, color: '#64748b', marginTop: 2 }}>{r.notes}</div>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <div className="mono" style={{ fontSize: 18, fontWeight: 700, color: '#1e3a5f' }}>{r.dur}<span style={{ fontSize: 10, color: '#64748b', marginLeft: 2 }}>m</span></div>
                        <div className="mono" style={{ fontSize: 10, color: '#64748b', marginTop: 2 }}>{fmt12(r.start).replace(/[ap]m/, '')}</div>
                      </div>
                    </div>
                  );
                })}
                <button style={{ padding: '8px', border: '1.5px dashed #cbd5e1', background: 'transparent', color: '#64748b', borderRadius: 10, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>+ Add activity to {p.title}</button>
              </div>
            </div>
          ))}
        </div>

        {/* Right rail: focus cards */}
        <div style={{ padding: '28px 28px', background: '#fff', borderLeft: '1px solid #e2e8f0' }}>
          <div className="mono" style={{ fontSize: 10, letterSpacing: 1.5, color: '#64748b', fontWeight: 700, marginBottom: 10 }}>FOCUS</div>
          {[
            { l: 'Offense', v: data.focus.off, c: '#14b8a6' },
            { l: 'Defense', v: data.focus.def, c: '#f97316' },
          ].map((f, i) => (
            <div key={i} style={{ padding: 14, background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 10, marginBottom: 8 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: f.c, letterSpacing: 0.5, textTransform: 'uppercase' }}>{f.l}</div>
              <div style={{ fontSize: 13, fontWeight: 500, marginTop: 4 }}>{f.v}</div>
            </div>
          ))}

          <div className="mono" style={{ fontSize: 10, letterSpacing: 1.5, color: '#64748b', fontWeight: 700, marginTop: 20, marginBottom: 10 }}>TIME BALANCE</div>
          <svg viewBox="0 0 200 200" width="200" height="200">
            {(() => {
              const parts = phases.map(p => ({ v: p.ids.reduce((s, id) => s + byId[id].dur, 0), c: p.tint }));
              const total = parts.reduce((s, x) => s + x.v, 0);
              let ang = -Math.PI / 2;
              return parts.map((p, i) => {
                const delta = (p.v / total) * Math.PI * 2;
                const x1 = 100 + 80 * Math.cos(ang), y1 = 100 + 80 * Math.sin(ang);
                const x2 = 100 + 80 * Math.cos(ang + delta), y2 = 100 + 80 * Math.sin(ang + delta);
                const large = delta > Math.PI ? 1 : 0;
                const d = `M 100 100 L ${x1} ${y1} A 80 80 0 ${large} 1 ${x2} ${y2} Z`;
                ang += delta;
                return <path key={i} d={d} fill={p.c} stroke="#fff" strokeWidth="3" />;
              });
            })()}
            <circle cx="100" cy="100" r="40" fill="#fff" />
            <text x="100" y="98" textAnchor="middle" fontSize="24" fontWeight="700" fill="#1e3a5f" fontFamily="DM Sans">120</text>
            <text x="100" y="114" textAnchor="middle" fontSize="10" fill="#64748b" fontFamily="JetBrains Mono">MINUTES</text>
          </svg>

          <div className="mono" style={{ fontSize: 10, letterSpacing: 1.5, color: '#64748b', fontWeight: 700, marginTop: 16, marginBottom: 8 }}>QUOTE OF DAY</div>
          <div style={{ fontSize: 13, fontStyle: 'italic', color: '#1e3a5f', borderLeft: '3px solid #14b8a6', paddingLeft: 10 }}>
            "Your rebound rate is a choice."
          </div>
        </div>
      </div>
    </div>
  );
}

window.SessionStoryboard = SessionStoryboard;
