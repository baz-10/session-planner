// Basketball court backgrounds - 3 visual directions
// All use viewBox 0 0 1000 1000 for a half court

const HalfCourtLines = ({ strokeMajor = "#fff8ed", strokeMinor = "#fff8ed", widthMajor = 3.5, widthMinor = 2.4, laneFill = "none", laneOpacity = 0 }) => {
  const common = { fill: "none", strokeLinecap: "round", strokeLinejoin: "round" };
  return (
    <g>
      {/* boundary */}
      <rect x="74" y="74" width="852" height="852" stroke={strokeMajor} strokeWidth={widthMajor} {...common} />
      {/* key */}
      <rect x="378.5" y="74" width="243" height="206" stroke={strokeMajor} strokeWidth={widthMajor} {...common} />
      {laneOpacity > 0 && <rect x="378.5" y="74" width="243" height="206" fill={laneFill} opacity={laneOpacity} />}
      {/* free throw line */}
      <line x1="378.5" y1="280" x2="621.5" y2="280" stroke={strokeMajor} strokeWidth={widthMajor} {...common} />
      {/* restricted arc */}
      <path d="M 440 194 A 60 60 0 0 0 560 194" stroke={strokeMinor} strokeWidth={widthMinor} {...common} />
      {/* free throw circle (dashed) */}
      <path d="M 378.5 280 A 121.5 121.5 0 0 0 621.5 280" stroke={strokeMinor} strokeWidth={widthMinor} {...common} />
      <path d="M 378.5 280 A 121.5 121.5 0 0 1 621.5 280" stroke={strokeMinor} strokeWidth={widthMinor} strokeDasharray="10 10" {...common} />
      {/* three point line */}
      <path d="M 170 304 A 360 360 0 0 0 830 304" stroke={strokeMajor} strokeWidth={widthMajor} {...common} />
      <line x1="170" y1="74" x2="170" y2="304" stroke={strokeMajor} strokeWidth={widthMajor} {...common} />
      <line x1="830" y1="74" x2="830" y2="304" stroke={strokeMajor} strokeWidth={widthMajor} {...common} />
      {/* lane hashes */}
      {[123, 166, 210].map(y => (
        <React.Fragment key={y}>
          <line x1="365" y1={y} x2="378.5" y2={y} stroke={strokeMinor} strokeWidth={widthMinor} {...common} />
          <line x1="621.5" y1={y} x2="635" y2={y} stroke={strokeMinor} strokeWidth={widthMinor} {...common} />
        </React.Fragment>
      ))}
      {/* rim + backboard */}
      <line x1="460" y1="110" x2="540" y2="110" stroke={strokeMajor} strokeWidth={widthMajor} {...common} />
      <circle cx="500" cy="140" r="14" stroke={strokeMajor} strokeWidth={widthMinor} fill="none" />
      {/* half-court arc at the bottom */}
      <path d="M 415 926 A 85 85 0 0 1 585 926" stroke={strokeMinor} strokeWidth={widthMinor} {...common} />
    </g>
  );
};

// ------------------ Variant A: Premium Hardwood ------------------
const CourtHardwood = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 1000 1000" className={className} style={style} preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="h-wood-base" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#e4bf82" />
        <stop offset="55%" stopColor="#d6a764" />
        <stop offset="100%" stopColor="#b58146" />
      </linearGradient>
      <pattern id="h-wood-planks" patternUnits="userSpaceOnUse" width="54" height="1000" patternTransform="rotate(0)">
        <rect width="54" height="1000" fill="url(#h-wood-base)" />
        <rect x="0" width="1" height="1000" fill="#8e5a2a" opacity="0.55" />
        <rect x="6" width="0.8" height="1000" fill="#fff1d4" opacity="0.18" />
        <rect x="20" width="0.6" height="1000" fill="#8e5a2a" opacity="0.25" />
        <rect x="34" width="0.8" height="1000" fill="#fff1d4" opacity="0.12" />
        <rect x="46" width="0.6" height="1000" fill="#8e5a2a" opacity="0.3" />
      </pattern>
      <filter id="h-grain">
        <feTurbulence type="fractalNoise" baseFrequency="2 0.04" numOctaves="2" seed="3" />
        <feColorMatrix values="0 0 0 0 0.35  0 0 0 0 0.22  0 0 0 0 0.1  0 0 0 0.35 0" />
        <feComposite in2="SourceGraphic" operator="in" />
      </filter>
      <radialGradient id="h-spot" cx="50%" cy="35%" r="75%">
        <stop offset="0%" stopColor="#fff6e3" stopOpacity="0.35" />
        <stop offset="55%" stopColor="#fff6e3" stopOpacity="0" />
        <stop offset="100%" stopColor="#3b1f08" stopOpacity="0.4" />
      </radialGradient>
      <linearGradient id="h-edge" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#000" stopOpacity="0.3" />
        <stop offset="15%" stopColor="#000" stopOpacity="0" />
        <stop offset="85%" stopColor="#000" stopOpacity="0" />
        <stop offset="100%" stopColor="#000" stopOpacity="0.35" />
      </linearGradient>
    </defs>
    <rect width="1000" height="1000" fill="url(#h-wood-planks)" />
    <rect width="1000" height="1000" fill="#000" opacity="0.08" filter="url(#h-grain)" />
    <rect width="1000" height="1000" fill="url(#h-spot)" />
    <rect width="1000" height="1000" fill="url(#h-edge)" />
    {/* lane painted area */}
    <rect x="378.5" y="74" width="243" height="206" fill="#0f1f33" opacity="0.55" />
    <rect x="378.5" y="74" width="243" height="206" fill="#14b8a6" opacity="0.12" />
    <HalfCourtLines strokeMajor="#fff8ed" strokeMinor="#fff8ed" widthMajor={4.5} widthMinor={3} />
    {/* logo at center */}
    <g opacity="0.28">
      <circle cx="500" cy="820" r="60" fill="none" stroke="#fff8ed" strokeWidth="2.5" />
      <text x="500" y="828" textAnchor="middle" fontFamily="DM Sans" fontWeight="700" fontSize="22" fill="#fff8ed" letterSpacing="2">TEAM</text>
    </g>
  </svg>
);

// ------------------ Variant B: Tactical Dark ------------------
const CourtTactical = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 1000 1000" className={className} style={style} preserveAspectRatio="xMidYMid slice">
    <defs>
      <radialGradient id="t-bg" cx="50%" cy="40%" r="80%">
        <stop offset="0%" stopColor="#142238" />
        <stop offset="60%" stopColor="#0b1424" />
        <stop offset="100%" stopColor="#050a14" />
      </radialGradient>
      <pattern id="t-grid" patternUnits="userSpaceOnUse" width="40" height="40">
        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#5eead4" strokeWidth="0.6" opacity="0.08" />
      </pattern>
      <filter id="t-glow" x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="2.5" result="b" />
        <feMerge>
          <feMergeNode in="b" />
          <feMergeNode in="SourceGraphic" />
        </feMerge>
      </filter>
      <radialGradient id="t-teal-glow" cx="50%" cy="15%" r="40%">
        <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.25" />
        <stop offset="100%" stopColor="#14b8a6" stopOpacity="0" />
      </radialGradient>
    </defs>
    <rect width="1000" height="1000" fill="url(#t-bg)" />
    <rect width="1000" height="1000" fill="url(#t-grid)" />
    <rect width="1000" height="1000" fill="url(#t-teal-glow)" />
    {/* lane */}
    <rect x="378.5" y="74" width="243" height="206" fill="#14b8a6" opacity="0.06" />
    <g filter="url(#t-glow)">
      <HalfCourtLines strokeMajor="#5eead4" strokeMinor="#5eead4" widthMajor={3.5} widthMinor={2.2} />
    </g>
    {/* corner tick marks */}
    {[[74,74],[926,74],[74,926],[926,926]].map(([x,y],i)=>(
      <g key={i} stroke="#5eead4" strokeWidth="2" opacity="0.7">
        <line x1={x-12} y1={y} x2={x+12} y2={y} />
        <line x1={x} y1={y-12} x2={x} y2={y+12} />
      </g>
    ))}
  </svg>
);

// ------------------ Variant C: Blueprint ------------------
const CourtBlueprint = ({ className = "", style = {} }) => (
  <svg viewBox="0 0 1000 1000" className={className} style={style} preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="b-bg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#1e3a5f" />
        <stop offset="100%" stopColor="#14243d" />
      </linearGradient>
      <pattern id="b-fine" patternUnits="userSpaceOnUse" width="25" height="25">
        <path d="M 25 0 L 0 0 0 25" fill="none" stroke="#ffffff" strokeWidth="0.4" opacity="0.1" />
      </pattern>
      <pattern id="b-coarse" patternUnits="userSpaceOnUse" width="125" height="125">
        <path d="M 125 0 L 0 0 0 125" fill="none" stroke="#ffffff" strokeWidth="0.8" opacity="0.18" />
      </pattern>
      <radialGradient id="b-vig" cx="50%" cy="50%" r="70%">
        <stop offset="60%" stopColor="#000" stopOpacity="0" />
        <stop offset="100%" stopColor="#000" stopOpacity="0.35" />
      </radialGradient>
    </defs>
    <rect width="1000" height="1000" fill="url(#b-bg)" />
    <rect width="1000" height="1000" fill="url(#b-fine)" />
    <rect width="1000" height="1000" fill="url(#b-coarse)" />
    {/* lane crosshatch */}
    <rect x="378.5" y="74" width="243" height="206" fill="#ffffff" opacity="0.05" />
    <HalfCourtLines strokeMajor="#ffffff" strokeMinor="#ffffff" widthMajor={3.2} widthMinor={2.2} />
    {/* measurement labels */}
    <g fontFamily="JetBrains Mono" fontSize="12" fill="#ffffff" opacity="0.55">
      <text x="500" y="62" textAnchor="middle">50'-0"</text>
      <text x="500" y="296" textAnchor="middle">15'-0"</text>
      <text x="60" y="194" textAnchor="middle" transform="rotate(-90 60 194)">19'-9"</text>
    </g>
    <rect width="1000" height="1000" fill="url(#b-vig)" />
  </svg>
);

window.CourtHardwood = CourtHardwood;
window.CourtTactical = CourtTactical;
window.CourtBlueprint = CourtBlueprint;
window.HalfCourtLines = HalfCourtLines;
