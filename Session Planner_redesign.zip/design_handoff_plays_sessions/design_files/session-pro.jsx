// Session Pro - dense, spreadsheet-esque but elevated and hi-fi
function SessionPro() {
  const data = window.SESSION_DATA;
  const fmt12 = window.fmt12, addMinutes = window.addMinutes;
  let clock = data.start;
  const rows = data.activities.map(a => {
    const s = clock; clock = addMinutes(clock, a.dur);
    return { ...a, start: s, end: clock };
  });
  const used = rows.reduce((s, r) => s + r.dur, 0);

  return (
    <div style={{ width: 1280, background: '#0f1f33', fontFamily: 'DM Sans', color: '#e2e8f0', minHeight: 800 }}>
      {/* Top dense bar */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', padding: '20px 28px', borderBottom: '1px solid rgba(255,255,255,0.08)', alignItems: 'center' }}>
        <div>
          <div className="mono" style={{ fontSize: 10, letterSpacing: 2, color: '#5eead4', fontWeight: 700 }}>SESSION · DRAFT</div>
          <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: -0.3, marginTop: 4 }}>{data.name}</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={{ background: 'rgba(255,255,255,0.05)', color: '#e2e8f0', border: '1px solid rgba(255,255,255,0.12)', padding: '7px 12px', borderRadius: 8, fontSize: 12, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>⌘K · Commands</button>
          <button style={{ background: 'rgba(255,255,255,0.05)', color: '#e2e8f0', border: '1px solid rgba(255,255,255,0.12)', padding: '7px 12px', borderRadius: 8, fontSize: 12, fontWeight: 600, fontFamily: 'inherit', cursor: 'pointer' }}>Print</button>
          <button style={{ background: '#14b8a6', color: '#fff', border: 'none', padding: '7px 14px', borderRadius: 8, fontSize: 12, fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer' }}>Save</button>
        </div>
      </div>

      {/* Inline metadata strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 1, background: 'rgba(255,255,255,0.08)', padding: '1px 0' }}>
        {[
          ['Date', data.date],
          ['Start', fmt12(data.start)],
          ['Length', `${data.duration} min`],
          ['Location', data.location.split(' · ')[1] || data.location],
          ['Off focus', data.focus.off],
          ['Def focus', data.focus.def],
        ].map(([l, v], i) => (
          <div key={i} style={{ background: '#0f1f33', padding: '12px 18px' }}>
            <div className="mono" style={{ fontSize: 10, letterSpacing: 1.2, color: '#64748b', fontWeight: 600 }}>{l.toUpperCase()}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#fff', marginTop: 2 }}>{v}</div>
          </div>
        ))}
      </div>

      {/* Progress bar */}
      <div style={{ padding: '14px 28px', background: 'rgba(255,255,255,0.02)', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
          <div className="mono" style={{ fontSize: 11, color: '#94a3b8' }}>TIME ALLOCATED · {used}/{data.duration} MIN</div>
          <div className="mono" style={{ fontSize: 11, color: used === data.duration ? '#22c55e' : '#f59e0b' }}>{used === data.duration ? '✓ Balanced' : `${data.duration - used} left`}</div>
        </div>
        <div style={{ display: 'flex', height: 8, borderRadius: 4, overflow: 'hidden', background: 'rgba(255,255,255,0.06)' }}>
          {rows.map(r => <div key={r.id} style={{ flex: r.dur, background: r.color, borderRight: '1px solid #0f1f33' }} />)}
        </div>
      </div>

      {/* Dense table */}
      <div style={{ padding: '0 28px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '40px 80px 80px 1fr 140px 200px 1fr 80px', gap: 0, padding: '10px 0', borderBottom: '1px solid rgba(255,255,255,0.08)', fontSize: 10, letterSpacing: 1.2, color: '#64748b', fontFamily: 'JetBrains Mono', fontWeight: 600 }}>
          <div style={{ textAlign: 'center' }}>#</div>
          <div>START</div>
          <div>MIN</div>
          <div>ACTIVITY</div>
          <div>CATEGORY</div>
          <div>LINKED PLAY</div>
          <div>NOTES</div>
          <div style={{ textAlign: 'right' }}>LEFT</div>
        </div>
        {rows.map((r, i) => {
          const left = data.duration - rows.slice(0, i + 1).reduce((s, x) => s + x.dur, 0);
          return (
            <div key={r.id} style={{ display: 'grid', gridTemplateColumns: '40px 80px 80px 1fr 140px 200px 1fr 80px', gap: 0, padding: '12px 0', borderBottom: '1px solid rgba(255,255,255,0.06)', alignItems: 'center', fontSize: 13 }}>
              <div style={{ textAlign: 'center', color: '#64748b', fontSize: 11 }}>⋮⋮ {i + 1}</div>
              <div className="mono" style={{ fontSize: 12, color: '#e2e8f0' }}>{fmt12(r.start).replace(/[ap]m/, '')}</div>
              <div className="mono" style={{ fontSize: 14, fontWeight: 700, color: '#5eead4' }}>{r.dur}</div>
              <div style={{ fontWeight: 600, color: '#fff', display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ width: 4, height: 20, borderRadius: 2, background: r.color }} />
                {r.name}
              </div>
              <div>
                <span style={{ fontSize: 11, padding: '3px 8px', borderRadius: 100, background: r.color + '33', color: r.color, fontWeight: 700, letterSpacing: 0.4, textTransform: 'uppercase' }}>{r.cat}</span>
              </div>
              <div>
                {r.play ? (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ width: 32, height: 22, borderRadius: 4, overflow: 'hidden', background: '#050a14', position: 'relative' }}>
                      <CourtBlueprint style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
                    </div>
                    <div style={{ fontSize: 12, color: '#5eead4', fontWeight: 600 }}>{r.play}</div>
                  </div>
                ) : <div style={{ fontSize: 12, color: '#475569' }}>— link —</div>}
              </div>
              <div style={{ fontSize: 12, color: '#94a3b8' }}>{r.notes}</div>
              <div className="mono" style={{ fontSize: 12, color: left >= 0 ? '#64748b' : '#ef4444', textAlign: 'right' }}>{left}</div>
            </div>
          );
        })}
      </div>

      <div style={{ padding: '16px 28px', display: 'flex', gap: 10 }}>
        <button style={{ padding: '8px 14px', fontSize: 12, fontWeight: 600, border: '1px solid rgba(94,234,212,0.4)', color: '#5eead4', background: 'transparent', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>+ Activity</button>
        <button style={{ padding: '8px 14px', fontSize: 12, fontWeight: 600, border: '1px solid rgba(255,255,255,0.12)', color: '#e2e8f0', background: 'transparent', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>+ From library</button>
        <button style={{ padding: '8px 14px', fontSize: 12, fontWeight: 700, border: 'none', color: '#0f1f33', background: '#5eead4', borderRadius: 8, cursor: 'pointer', fontFamily: 'inherit' }}>✦ Autopilot plan</button>
      </div>
    </div>
  );
}

window.SessionPro = SessionPro;
