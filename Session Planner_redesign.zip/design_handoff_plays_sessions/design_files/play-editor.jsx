// Play Editor screen - shows the 3 court themes in situ with editor chrome
// Each variant = a full editor shell, different court theme

const PLAYERS = [
  { id: 'p1', type: 'offense', label: '1', x: 500, y: 760 },
  { id: 'p2', type: 'offense', label: '2', x: 840, y: 220 },
  { id: 'p3', type: 'offense', label: '3', x: 160, y: 220 },
  { id: 'p4', type: 'offense', label: '4', x: 400, y: 460 },
  { id: 'p5', type: 'offense', label: '5', x: 600, y: 460 },
  { id: 'd1', type: 'defense', label: 'X1', x: 500, y: 700 },
  { id: 'd4', type: 'defense', label: 'X4', x: 400, y: 400 },
  { id: 'd5', type: 'defense', label: 'X5', x: 600, y: 400 },
];

const ACTIONS = [
  { type: 'pass', from: { x: 500, y: 760 }, to: { x: 400, y: 460 }, color: '#5eead4' },
  { type: 'cut', from: { x: 500, y: 760 }, to: { x: 300, y: 430 }, color: '#fbbf24' },
  { type: 'screen', from: { x: 600, y: 460 }, to: { x: 440, y: 460 }, color: '#f97316' },
  { type: 'dribble', from: { x: 400, y: 460 }, to: { x: 250, y: 320 }, color: '#5eead4' },
];

// Chevron arrow helper
function ArrowHead({ from, to, color, type }) {
  const dx = to.x - from.x, dy = to.y - from.y;
  const ang = Math.atan2(dy, dx);
  const tip = { x: to.x, y: to.y };
  const w = 14;
  const a1 = { x: tip.x - w * Math.cos(ang - Math.PI / 7), y: tip.y - w * Math.sin(ang - Math.PI / 7) };
  const a2 = { x: tip.x - w * Math.cos(ang + Math.PI / 7), y: tip.y - w * Math.sin(ang + Math.PI / 7) };
  if (type === 'screen') {
    // T-cap
    const perpAng = ang + Math.PI / 2;
    const t1 = { x: tip.x + 16 * Math.cos(perpAng), y: tip.y + 16 * Math.sin(perpAng) };
    const t2 = { x: tip.x - 16 * Math.cos(perpAng), y: tip.y - 16 * Math.sin(perpAng) };
    return <line x1={t1.x} y1={t1.y} x2={t2.x} y2={t2.y} stroke={color} strokeWidth="4" strokeLinecap="round" />;
  }
  return (
    <polygon points={`${tip.x},${tip.y} ${a1.x},${a1.y} ${a2.x},${a2.y}`} fill={color} />
  );
}

function ActionLine({ action }) {
  const dashed = action.type === 'pass' ? '10 8' : action.type === 'dribble' ? null : null;
  const wavy = action.type === 'dribble';
  if (wavy) {
    // squiggle
    const { from, to } = action;
    const dx = to.x - from.x, dy = to.y - from.y;
    const len = Math.sqrt(dx * dx + dy * dy);
    const steps = Math.max(6, Math.floor(len / 20));
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const bx = from.x + dx * t;
      const by = from.y + dy * t;
      const perpX = -dy / len, perpY = dx / len;
      const amp = Math.sin(t * Math.PI * 8) * 8;
      pts.push(`${bx + perpX * amp},${by + perpY * amp}`);
    }
    return (
      <g>
        <polyline points={pts.join(' ')} fill="none" stroke={action.color} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        <ArrowHead from={action.from} to={action.to} color={action.color} type={action.type} />
      </g>
    );
  }
  return (
    <g>
      <line x1={action.from.x} y1={action.from.y} x2={action.to.x} y2={action.to.y}
        stroke={action.color} strokeWidth="4" strokeLinecap="round"
        strokeDasharray={dashed || undefined} />
      <ArrowHead from={action.from} to={action.to} color={action.color} type={action.type} />
    </g>
  );
}

function PlayerToken({ player, theme }) {
  const isOff = player.type === 'offense';
  const bg = isOff
    ? (theme === 'hardwood' ? '#fff8ed' : theme === 'tactical' ? '#5eead4' : '#ffffff')
    : (theme === 'hardwood' ? '#0f1f33' : theme === 'tactical' ? '#f97316' : '#1e3a5f');
  const fg = isOff
    ? (theme === 'hardwood' ? '#0f1f33' : theme === 'tactical' ? '#0b1424' : '#1e3a5f')
    : (theme === 'hardwood' ? '#fff8ed' : '#ffffff');
  const stroke = isOff
    ? (theme === 'tactical' ? '#14b8a6' : theme === 'hardwood' ? '#0f1f33' : '#5eead4')
    : 'none';
  return (
    <g>
      {isOff && theme === 'tactical' && (
        <circle cx={player.x} cy={player.y} r="30" fill="#5eead4" opacity="0.18" />
      )}
      <circle cx={player.x} cy={player.y} r="22" fill={bg} stroke={stroke} strokeWidth="2" />
      <text x={player.x} y={player.y + 7} textAnchor="middle"
        fontFamily="DM Sans" fontWeight="700" fontSize="22" fill={fg}>{player.label}</text>
    </g>
  );
}

function CourtSurface({ theme }) {
  if (theme === 'hardwood') return <CourtHardwood style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />;
  if (theme === 'tactical') return <CourtTactical style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />;
  return <CourtBlueprint style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />;
}

function PlayDiagram({ theme, size = 620 }) {
  return (
    <div style={{ position: 'relative', width: size, height: size, borderRadius: 18, overflow: 'hidden',
      boxShadow: theme === 'tactical' ? '0 30px 80px rgba(0,0,0,0.45), inset 0 0 0 1px rgba(94,234,212,0.25)' :
                 theme === 'blueprint' ? '0 30px 80px rgba(15,31,51,0.4), inset 0 0 0 1px rgba(255,255,255,0.12)' :
                 '0 30px 80px rgba(61,31,8,0.35), inset 0 0 0 1px rgba(0,0,0,0.15)' }}>
      <CourtSurface theme={theme} />
      <svg viewBox="0 0 1000 1000" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        {ACTIONS.map((a, i) => <ActionLine key={i} action={a} />)}
        {PLAYERS.map(p => <PlayerToken key={p.id} player={p} theme={theme} />)}
        {/* ball */}
        <g>
          <circle cx="400" cy="460" r="10" fill="#f97316" stroke="#7c2d12" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

// Editor chrome around the court
function PlayEditorShell({ theme: initialTheme = 'hardwood', title, subtitle, storageKey = 'play-editor-theme' }) {
  const [theme, setThemeState] = React.useState(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved === 'hardwood' || saved === 'tactical' || saved === 'blueprint') return saved;
    } catch (e) {}
    return initialTheme;
  });
  const setTheme = (t) => {
    setThemeState(t);
    try { localStorage.setItem(storageKey, t); } catch (e) {}
  };
  const isDark = theme === 'tactical' || theme === 'blueprint';
  const panelBg = isDark ? '#0f1f33' : '#ffffff';
  const panelInk = isDark ? '#e2e8f0' : '#0f1f33';
  const subtleInk = isDark ? '#94a3b8' : '#64748b';
  const borderCol = isDark ? 'rgba(255,255,255,0.08)' : '#e2e8f0';
  const chipBg = isDark ? 'rgba(148,163,184,0.12)' : '#f1f5f9';

  const Tool = ({ icon, label, active }) => (
    <button style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '10px 8px',
      background: active ? 'var(--teal)' : 'transparent', border: 'none', borderRadius: 10, cursor: 'pointer',
      color: active ? '#fff' : panelInk, width: 64, fontFamily: 'inherit',
    }}>
      <div style={{ fontSize: 20, lineHeight: 1 }}>{icon}</div>
      <div style={{ fontSize: 10, fontWeight: 600, letterSpacing: 0.3, textTransform: 'uppercase', opacity: 0.85 }}>{label}</div>
    </button>
  );

  const Phase = ({ n, name, active }) => (
    <div style={{
      padding: '10px 14px', borderRadius: 10, minWidth: 120,
      background: active ? (isDark ? 'rgba(20,184,166,0.18)' : 'var(--teal-glow)') : chipBg,
      border: `1.5px solid ${active ? 'var(--teal)' : 'transparent'}`,
      cursor: 'pointer',
    }}>
      <div className="mono" style={{ fontSize: 10, color: subtleInk, fontWeight: 600 }}>PHASE {n}</div>
      <div style={{ fontSize: 13, fontWeight: 600, color: panelInk, marginTop: 2 }}>{name}</div>
    </div>
  );

  return (
    <div style={{
      width: 1280, background: isDark ? '#050a14' : '#f8fafc', borderRadius: 0,
      fontFamily: 'DM Sans', color: panelInk, overflow: 'hidden',
      padding: 0,
    }}>
      {/* Top bar */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '18px 28px', background: panelBg, borderBottom: `1px solid ${borderCol}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <button style={{ background: 'transparent', border: `1px solid ${borderCol}`, color: panelInk, padding: '6px 10px', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontFamily: 'inherit' }}>← Plays</button>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: -0.2 }}>{title}</div>
            <div style={{ fontSize: 12, color: subtleInk }}>{subtitle} · Half court · v4 · Auto-saved 14s ago</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ display: 'flex', gap: 4, background: chipBg, padding: 3, borderRadius: 10 }}>
            {[['hardwood','Hardwood'], ['tactical','Tactical'], ['blueprint','Blueprint']].map(([key, label]) => (
              <button key={key} onClick={() => setTheme(key)} style={{
                padding: '6px 12px', borderRadius: 7, fontSize: 12, fontWeight: 600,
                background: key === theme ? 'var(--teal)' : 'transparent',
                color: key === theme ? '#fff' : panelInk,
                border: 'none', cursor: 'pointer', fontFamily: 'inherit',
              }}>{label}</button>
            ))}
          </div>
          <button style={{ background: 'transparent', border: `1px solid ${borderCol}`, color: panelInk, padding: '8px 14px', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>Export</button>
          <button style={{ background: 'var(--navy)', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>Save play</button>
        </div>
      </div>

      {/* Main editor grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '88px 1fr 300px', gap: 0, minHeight: 740 }}>
        {/* Left toolbar */}
        <div style={{ background: panelBg, borderRight: `1px solid ${borderCol}`, padding: '18px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 1, color: subtleInk, marginBottom: 4 }}>ADD</div>
          <Tool icon="○" label="Off" />
          <Tool icon="◆" label="Def" />
          <Tool icon="●" label="Ball" active />
          <Tool icon="△" label="Cone" />
          <Tool icon="T" label="Text" />
          <div style={{ width: 40, height: 1, background: borderCol, margin: '8px 0' }} />
          <div style={{ fontSize: 9, fontWeight: 700, letterSpacing: 1, color: subtleInk, marginBottom: 4 }}>ACT</div>
          <Tool icon="→" label="Cut" />
          <Tool icon="⇢" label="Pass" />
          <Tool icon="〰" label="Dribble" />
          <Tool icon="⊥" label="Screen" />
          <Tool icon="◎" label="Shot" />
        </div>

        {/* Court area */}
        <div style={{
          background: isDark ? 'radial-gradient(1200px 600px at 50% -20%, rgba(20,184,166,0.08), transparent 70%), #050a14' : '#f8fafc',
          padding: '28px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 20,
        }}>
          <PlayDiagram theme={theme} size={620} />
          {/* Phase track */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, background: panelBg, border: `1px solid ${borderCol}`, borderRadius: 14, padding: '10px 14px', width: '100%', maxWidth: 720 }}>
            <button style={{ background: 'var(--teal)', color: '#fff', border: 'none', width: 38, height: 38, borderRadius: 10, fontSize: 14, cursor: 'pointer' }}>▶</button>
            <div style={{ display: 'flex', gap: 6, flex: 1, overflow: 'hidden' }}>
              <Phase n="1" name="Setup" active />
              <Phase n="2" name="Entry pass" />
              <Phase n="3" name="Ball screen" />
              <Phase n="4" name="Finish" />
            </div>
            <button style={{ background: 'transparent', border: `1.5px dashed ${borderCol}`, color: subtleInk, padding: '6px 12px', borderRadius: 10, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>+ Phase</button>
          </div>
        </div>

        {/* Right inspector */}
        <div style={{ background: panelBg, borderLeft: `1px solid ${borderCol}`, padding: '22px 20px', overflowY: 'auto' }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.2, color: subtleInk, textTransform: 'uppercase' }}>Selected</div>
          <div style={{ fontSize: 16, fontWeight: 700, marginTop: 4, marginBottom: 14 }}>Player 4 (PF)</div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <div style={{ fontSize: 11, color: subtleInk, marginBottom: 4 }}>Label</div>
              <div style={{ background: chipBg, padding: '8px 10px', borderRadius: 8, fontSize: 13, fontWeight: 600 }}>4</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: subtleInk, marginBottom: 4 }}>Role</div>
              <div style={{ background: chipBg, padding: '8px 10px', borderRadius: 8, fontSize: 13, fontWeight: 600 }}>Offense</div>
            </div>
          </div>

          <div style={{ marginTop: 22 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.2, color: subtleInk, textTransform: 'uppercase', marginBottom: 10 }}>Actions from this player</div>
            {[
              { t: 'Receive pass', d: 'from 1 · 0.9s', c: '#5eead4' },
              { t: 'Dribble drive', d: 'to wing · 1.2s', c: '#14b8a6' },
            ].map((a, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: chipBg, borderRadius: 10, marginBottom: 6 }}>
                <div style={{ width: 6, height: 28, borderRadius: 3, background: a.c }} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{a.t}</div>
                  <div style={{ fontSize: 11, color: subtleInk }}>{a.d}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 22 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.2, color: subtleInk, textTransform: 'uppercase', marginBottom: 10 }}>Coaching notes</div>
            <div style={{ background: chipBg, borderRadius: 10, padding: 12, fontSize: 13, lineHeight: 1.5, color: panelInk }}>
              4 reads defender: if help, kick to 2 in corner. If trail, attack baseline.
            </div>
          </div>

          <div style={{ marginTop: 22 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: 1.2, color: subtleInk, textTransform: 'uppercase', marginBottom: 10 }}>Tags</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {['horns', 'ball-screen', 'quick-hitter', '5-out'].map(t => (
                <span key={t} style={{ fontSize: 11, padding: '4px 10px', borderRadius: 100, background: 'rgba(20,184,166,0.15)', color: 'var(--teal)', fontWeight: 600 }}>{t}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

window.PlayEditorShell = PlayEditorShell;
window.PlayDiagram = PlayDiagram;
