# Handoff: Plays & Session Planner Redesign

## Overview
Redesign of two screens in the Session Planner app:

1. **Play editor** (`/dashboard/plays/[id]`) — the basketball court background is elevated from a single flat SVG to a **switchable theme system** with three visual directions. The theme switcher lives in the editor's top bar and persists per user.
2. **Session planning / builder** (`/dashboard/sessions/[id]`) — the current dense spreadsheet-style layout is replaced with a richer information architecture. Three design directions are bundled; pick one to implement (recommendation below).

The HTML files in `design_files/` are **design references**, not production code. Recreate them inside the existing Next.js + Tailwind + React codebase using the established patterns (components under `src/components/...`, hooks like `usePlays` / `useSessions`, `@dnd-kit` for drag-and-drop, `react-konva` for the play canvas, the existing brand tokens in `tailwind.config.ts` / `public/brand-kit.html`).

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interactions are final. Match the mocks pixel-for-pixel where possible, using the codebase's existing primitives (`<Button>`, `<Card>`, `<Badge>`, `<Modal>`) rather than re-inventing them. The raw HTML/JSX in `design_files/` uses inline styles for speed — translate those into Tailwind utility classes consistent with the rest of the app.

---

## Part 1 — Plays: Court backgrounds + theme toggle

### What changes
The existing static SVGs in `public/courts/*.svg` are replaced with **three themed court surfaces**, and the user can switch between them from the editor top bar. The selection persists (localStorage for V1; move to `user_preferences` table later).

### The three themes
All use viewBox `0 0 1000 1000`, identical half-court line geometry (boundary, key, free-throw arc, three-point line, lane hashes, backboard+rim, half-court arc). Only the surface treatment and line color change. See `design_files/courts.jsx` for the full SVG implementation of each.

#### A · Hardwood (default)
- **Feeling:** premium NBA-broadcast hardwood, warm and cinematic.
- **Base:** vertical plank pattern, 54px repeat. Plank base is a linear gradient from `#e4bf82` → `#d6a764` → `#b58146` (top → bottom).
- **Plank detail:** four thin vertical stripes per repeat — `#8e5a2a` @ 0.55 opacity (seam), `#fff1d4` @ 0.18 (highlight), `#8e5a2a` @ 0.25 (mid seam), `#fff1d4` @ 0.12 (highlight), `#8e5a2a` @ 0.3 (seam).
- **Grain overlay:** SVG `feTurbulence` (baseFrequency `2 0.04`, 2 octaves, seed 3), colored to brown at 0.35 opacity, composited over the planks at 0.08 opacity.
- **Spotlight:** radial gradient centered 50%/35%, 75% radius — `#fff6e3` @ 0.35 → transparent → `#3b1f08` @ 0.4.
- **Edge vignette:** top/bottom darkening linear gradient, 0.3 / 0 / 0 / 0.35.
- **Lane paint:** `#0f1f33` @ 0.55 with `#14b8a6` @ 0.12 stacked on top.
- **Lines:** `#fff8ed`, major 4.5px, minor 3px.
- **Logo mark:** faint circle at (500, 820), r=60, `#fff8ed` @ 0.28, with "TEAM" text (DM Sans 700, 22px, letterSpacing 2).

#### B · Tactical (dark)
- **Feeling:** film-room / coach's tablet — charcoal with glowing teal line work.
- **Base:** radial gradient centered 50%/40%, 80% radius — `#142238` → `#0b1424` → `#050a14`.
- **Grid:** 40×40 px dot grid lines, `#5eead4` @ 0.08.
- **Top-of-court teal haze:** radial gradient at 50%/15%, 40% radius, teal 0.25 → 0.
- **Lane:** `#14b8a6` @ 0.06.
- **Lines:** `#5eead4`, major 3.5px, minor 2.2px, wrapped in a Gaussian-blur `feGlow` filter (stdDeviation 2.5) for a subtle glow.
- **Corners:** four crosshair ticks at the court corners, `#5eead4` @ 0.7, 24px.

#### C · Blueprint
- **Feeling:** architect's drafting sheet — schematic, technical.
- **Base:** linear gradient `#1e3a5f` → `#14243d`.
- **Grid:** fine 25px grid (`#fff` @ 0.1) + coarse 125px grid (`#fff` @ 0.18).
- **Lane:** white @ 0.05.
- **Lines:** `#ffffff`, major 3.2px, minor 2.2px.
- **Dimension labels:** JetBrains Mono 12px, white @ 0.55, e.g. `50'-0"` at top, `15'-0"` at free-throw line, `19'-9"` rotated on left edge.
- **Vignette:** outer radial, `#000` @ 0 → 0.35.

### Theme toggle
- **Location:** top right of the editor header, just before Export / Save buttons.
- **Widget:** segmented control, 3 options — Hardwood / Tactical / Blueprint. Container is `chipBg` (light mode: `#f1f5f9`; dark mode: `rgba(148,163,184,0.12)`), 3px padding, 10px radius. Active segment: `--teal` (`#14b8a6`), white text, 7px radius.
- **Persistence:** save to `localStorage` under key `play-editor-theme`. Value is one of `'hardwood' | 'tactical' | 'blueprint'`. Read on mount, fall back to `'hardwood'`.
- **Applies to:** the active play-editor canvas, thumbnails in the play library (each play should render with the user's chosen theme), linked-play previews in the session builder.
- **Future (note for the codex pass):** expose as a field on `user_preferences` keyed by user id so it syncs across devices. Also allow per-play override as a later enhancement.

### Editor chrome around the court (shown in `play-editor.jsx`)
The surrounding editor chrome is tightened at the same time — it's what makes the court feel premium in context:

- **Top bar:** `← Plays` back button · play title (DM Sans 700, 20px) · subtitle (12px `--cool-gray`: `{playType} · Half court · v{N} · Auto-saved {Xs} ago`) · theme toggle · `Export` outline button · `Save play` navy primary.
- **Grid:** `88px | 1fr | 300px` — left toolbar, court area, right inspector.
- **Left toolbar:** vertical stack, two labeled groups (`ADD` — Off / Def / Ball / Cone / Text; `ACT` — Cut / Pass / Dribble / Screen / Shot). Each tool is a 64px square with icon + caps label. Active tool: `--teal` bg, white fg.
- **Court area:** centered court (620px square, 18px radius, drop shadow varies by theme — see `play-editor.jsx`). Below the court is a **phase track** — play/pause button + horizontally scrolling phase chips + `+ Phase` dashed button. Active phase has a `--teal` border and tinted background.
- **Right inspector (300px):** Selected-object section with label/role fields, "Actions from this player" list (each row shows a colored swatch, action name, timing), coaching notes (multiline), tags (teal pill chips).

### Players, actions, and ball
When rendering on the themed courts, the player tokens adapt:

| Theme | Offense fill | Offense stroke | Offense label | Defense fill | Defense label |
| ---- | ---- | ---- | ---- | ---- | ---- |
| Hardwood | `#fff8ed` | `#0f1f33` (2px) | `#0f1f33` | `#0f1f33` | `#fff8ed` |
| Tactical | `#5eead4` | `#14b8a6` (2px) + soft halo `#5eead4` @ 0.18 r=30 | `#0b1424` | `#f97316` | `#fff` |
| Blueprint | `#ffffff` | `#5eead4` (2px) | `#1e3a5f` | `#1e3a5f` | `#fff` |

Token: 22px circle, DM Sans 700/22px label.

Action line colors stay constant across themes:
- **Pass:** `#5eead4`, 4px, dashed `10 8`, filled arrowhead.
- **Cut:** `#fbbf24`, 4px, solid, filled arrowhead.
- **Dribble:** `#5eead4`, 4px, sine-wave squiggle (amplitude ~8, ~8 cycles over the segment), arrowhead.
- **Screen:** `#f97316`, 4px, solid, T-cap terminator (16px perpendicular line instead of arrow).

Ball: 10px orange circle (`#f97316`, stroke `#7c2d12` 1.5px).

### Files affected (target codebase)
- `public/courts/` — replace or augment the three SVGs with the new designs, OR port the SVG-as-JSX into a new `src/components/plays/court-surface.tsx` component (recommended — it lets the theme re-use player-token color logic).
- `src/components/plays/play-editor.tsx` — add the theme segmented control in the header row, wire to localStorage, pass theme to the court component and to the token-rendering helpers.
- `src/components/plays/play-library.tsx` — use the theme when rendering `thumbnail_data_url` fallback and when regenerating thumbnails.
- `src/components/sessions/activity-row.tsx` / `activity-table.tsx` — linked-play thumbnail previews should render with the selected theme.

---

## Part 2 — Session planning page

Three directions are included. **Recommended to implement: Direction A (Timeline & ribbon)** — it preserves the spreadsheet density coaches rely on while adding a scannable time ribbon and richer activity cards. Directions B/C are included as references; pick from them to fold in details (the phase grouping from B, the dense dark "pro" mode from C).

### Shared session data model (unchanged)
No schema changes — this is pure UI. The existing `sessions` + `session_activities` tables (with `linked_play_id`, `linked_play_thumbnail_data_url`, `category_id`, `additional_category_ids`, `duration`, `sort_order`, etc.) already have everything the designs need.

### Shared top-level tokens
- Background: `#f8fafc` (light mode variants) or `#0f1f33` (pro dark).
- Card: `#ffffff`, 1px border `#e2e8f0`, 12–14px radius.
- Hero gradient (A): `linear-gradient(135deg, #1e3a5f 0%, #0f1f33 100%)`.
- Primary action: `#14b8a6` (teal) bg, `#fff` fg, 700 weight.
- Secondary: transparent with `rgba(255,255,255,0.2)` border on the hero, `#e2e8f0` border on white.
- Category colors (consistent across all three directions):
  - Warmup `#94a3b8` · Passing `#f59e0b` · Defense `#ef4444` · Play `#14b8a6` · Conditioning `#8b5cf6` · Shooting `#eab308` · Live `#1e3a5f` · Wrap `#64748b`

### Direction A — Timeline & ribbon (recommended)
See `design_files/session-timeline.jsx`.

**Structure (1280px canvas; responsive down to the app's existing content width):**

1. **Hero band** (navy gradient, padding 28/36). Contains:
   - Eyebrow mono `SESSION PLAN` (DM Sans mono 12px, letterSpacing 2, teal).
   - H1 — session name (DM Sans 700, 30px, tracking -0.4).
   - Meta line — date · time range · location (14px, white @ 0.7).
   - Action row (right): `Duplicate`, `Print` outline-on-dark; `Save plan` teal primary.
   - **Stats strip** — 4-col grid (12px gap, 22px top margin). Cards: `Duration` (teal fill), `Activities`, `Offense focus`, `Defense focus`. Each card has mono eyebrow label (10px, 1.5 letter-spacing), 28px bold value, 11px mono subtitle.

2. **Timeline ribbon band** (white card, 24px padding). Contains:
   - Header: "Practice timeline" (16px bold) + start→end mono label.
   - Ribbon: flex row, 56px tall, 10px radius, 2px gaps, `#f1f5f9` backdrop. Each activity is a flex item with `flex: {dur}` and `background: {categoryColor}`. 10px bold white duration label with text-shadow inside, aligned bottom-left.
   - Below ribbon: start-time axis, 10px mono labels under each segment.

3. **Activities section** (36px padding). Header row: "Activities" title + `+ From library` teal outline · `+ Custom` neutral outline · `✦ Autopilot` gradient teal primary.

4. **Activity rows** (stack, 10px gap). Each row is a `72 | 72 | 1fr | 240 | 140 | 40` grid, 1px border, 14px radius:
   - Col 1 (duration block, colored `category` fill, white text): `#{idx}` mono, `{dur}` 16px mono bold, `MIN` 9px mono.
   - Col 2 (time column): `start` → `end` mono 10–13px on `#f8fafc` background.
   - Col 3 (main): activity name (15px bold) + category pill (tinted `categoryColor + '22'` bg, categoryColor text) + optional linked-play pill (navy bg with teal dot). Below: notes (13px cool-gray).
   - Col 4 (linked play preview, when present): 72×54 thumbnail rendered using the user's selected court theme + player dots. Label "Linked play · v{n} · synced".
   - Col 5 (assignees): stacked avatars (24px circles, -6px overlap, 2px white border).
   - Col 6: `⋮` overflow.

5. **Drag & drop:** keep existing `@dnd-kit` wiring; the grab affordance lives on the `⋮⋮` handle to the left of the row number (the design's `#{idx}` on col 1 doubles as the hit area).

### Direction B — Run of show (storyboard) — `session-storyboard.jsx`
Three-column shell: `180 | 1fr | 280`.
- **Left gutter:** clock markers grouped by phase. A 3px colored bar whose height scales with phase duration. Time in mono, phase name in 0.5-tracked uppercase.
- **Center:** activities grouped under phase headers (Warm-up / Skill block / Install · Plays / Competition / Cool down). Each card is `96 thumbnail | 1fr content | 80 time`. Phase headers are a colored dot + caps label + divider + mono duration total. Below each group: dashed `+ Add activity to {phase}` button.
- **Right rail:** Focus cards (offense/defense), a full SVG pie chart of time balance (200×200, with total minutes in the center donut hole), and a "Quote of day" blockquote with a teal left border.

### Direction C — Dense pro (dark) — `session-pro.jsx`
Dark navy (`#0f1f33`) surface, teal accents, spreadsheet-first.
- **Top bar:** mono eyebrow + H1 + `⌘K · Commands` / `Print` / `Save` buttons.
- **6-col inline metadata strip:** Date / Start / Length / Location / Off focus / Def focus. Each cell has a mono caps label and a 13px bold value.
- **Progress bar:** mono `TIME ALLOCATED · used/total MIN` label + check/warning state. 8px colored ribbon below, each segment is a flex-weighted duration.
- **Dense table:** `40 | 80 | 80 | 1fr | 140 | 200 | 1fr | 80` grid. Header row uses mono 10px caps. Rows use a 4×20 colored bar + bold name + category pill + tiny linked-play thumbnail + notes + mins-left.

---

## Design tokens (quick reference)

```css
/* Primary */
--navy: #1e3a5f;
--navy-light: #2d5a8a;
--navy-dark: #0f1f33;
--ink: #0a1628;

/* Accent */
--teal: #14b8a6;
--teal-light: #5eead4;
--teal-glow: rgba(20, 184, 166, 0.15);

/* Neutrals */
--warm-white: #fafafa;
--cool-gray: #64748b;
--whisper: #f1f5f9;
--border: #e2e8f0;

/* Status */
--success: #22c55e;
--warning: #eab308;
--error: #ef4444;
--orange: #f97316;
--purple: #8b5cf6;
```

- **Font families:** DM Sans (all UI text, 400–700), JetBrains Mono (stats, timestamps, labels with letter-spacing ≥ 1).
- **Radii:** 7 (segmented), 8 (buttons, inputs), 10 (chips, small cards), 12–14 (cards), 18 (court container).
- **Shadows:**
  - Default card: `0 1px 3px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04)`
  - Hardwood court: `0 30px 80px rgba(61,31,8,0.35), inset 0 0 0 1px rgba(0,0,0,0.15)`
  - Tactical court: `0 30px 80px rgba(0,0,0,0.45), inset 0 0 0 1px rgba(94,234,212,0.25)`
  - Blueprint court: `0 30px 80px rgba(15,31,51,0.4), inset 0 0 0 1px rgba(255,255,255,0.12)`

---

## Files in this bundle

- `design_files/redesign.html` — entry point. Open in a browser to see everything on a design canvas (pan/zoom, double-click to focus).
- `design_files/courts.jsx` — the three themed court SVG components.
- `design_files/play-editor.jsx` — editor shell with toolbar/inspector and the live theme toggle.
- `design_files/session-timeline.jsx` — Direction A (recommended).
- `design_files/session-storyboard.jsx` — Direction B.
- `design_files/session-pro.jsx` — Direction C (dark, dense).
- `design_files/main.jsx` — mounts everything on the design canvas.
- `design_files/design-canvas.jsx` — the canvas frame (not needed at implementation time).

## Implementation checklist

**Plays:**
- [ ] Create `CourtSurface` component with `theme` prop, porting the three SVGs from `courts.jsx`.
- [ ] Update `PlayerToken` render in `react-konva` to pick colors based on theme.
- [ ] Add segmented theme control to `play-editor.tsx` header; wire to localStorage under `play-editor-theme`.
- [ ] Thread the chosen theme into: main editor canvas, library thumbnails, linked-play thumbnails in sessions.
- [ ] Regenerate `thumbnail_data_url` with the selected theme on save.
- [ ] Tighten editor chrome per spec (left tool palette, right inspector, phase track with play/pause and `+ Phase` dashed button).

**Sessions (Direction A):**
- [ ] Replace the current top metadata form + chart with the hero band + 4-stat strip.
- [ ] Add the horizontal timeline ribbon component (color-weighted segments + start-time axis).
- [ ] Rebuild `ActivityRow` as a 6-column grid card per spec, including linked-play thumbnail column and assignee stack.
- [ ] Keep `@dnd-kit` reorder; hit area = colored duration block.
- [ ] Keep all existing logic (drill/play selectors, autopilot, save-to-library, PDF export) — only the presentation changes.
